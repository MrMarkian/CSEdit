                         ''~``
                        ( o o )
+------------------.oooO--(_)--Oooo.------------------+
|                                                     |
|                    .oooO         -- C SEdit --      |
|                    (   )   Oooo.                    |
+---------------------\ (----(   )--------------------+
                       \_)    ) /
                             (_/

(MORE WILL BE ADDED WHEN I CAN BE BOTHERED! :) )		

User Guide:

	BE CAREFULL this program can easily destroy a config if used incorrectly
	allways work on a backup of ur work and blaa de blaa de blaa! :)

	
	

Tips And Tricks:
	
	The command window is also usefull for copying settings
	from one config to another.. just select the settings u 
	want to copy, then right clck, select "Copy To Command Window"
	then load the config u want to copy it too, then select "Run All Commands"
	
	U can set the same value for different settings all at the same time.. saving
	valuable time and effort by selecting which settings u want to edit then typing
	the value in the Value: edit box

	Wanna make all your ships have the same setting? simple.. just select all from the 
	edit menu.. then right click on the listbox and select "Set This Setting To :" then "All"
	
	As long as the main window is in focus.. press ALT + V to make the View Settings popup menu
	appear wherever ur mouse is

	CSEdit will popup a message with whatever is in Notes\Note1 upon opening a cfg.. this is great
	if you have loads of cfg's coz u can write a description of what it is

	Drag And Drop Support! If u drop a cfg into the main window then it is loaded .. if more than
	1 cfg is dragged then multiple copies of CSEdit is opend

	Use Ctrl to select more than one setting.. use Shift to select all the settings from the
	current selection